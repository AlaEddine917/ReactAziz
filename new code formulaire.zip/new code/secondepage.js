import React from 'react';
import TextField from '@material-ui/core/TextField';
import { makeStyles } from '@material-ui/core/styles';
import Sani from './pano' 
import InputLabel from '@material-ui/core/InputLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import NativeSelect from '@material-ui/core/NativeSelect';
import Radio from '@material-ui/core/Radio';
import Too from './buttonradion'


const useStyles = makeStyles((theme) => ({
  root: {
    '& .MuiTextField-root': {
      margin: theme.spacing(1),
      width: '25ch',
    },
  },
}));

export default function FormPropsTextFields() {
  const classes = useStyles();
   const classess = useStyles();
  const [state, setState] = React.useState({
    age: '',
    name: 'hai',
  });

  const handleChange = (event) => {
    const name = event.target.name;
    setState({
      ...state,
      [name]: event.target.value,
    });
  };
  
  const [selectedValue, setSelectedValue] = React.useState('a');

  const handleChange1 = (event) => {
    setSelectedValue(event.target.value);
  };
  
  const [selectedDate, setSelectedDate] = React.useState(new Date('2014-08-18T21:11:54'));

  const handleDateChangehh = (date) => {
    setSelectedDate(date);
  };


  return (
    <form className={classes.root} noValidate autoComplete="off">
	
      <div>
	  <FormControl className={classes.formControl}>
        <InputLabel htmlFor="age-native-simple">educational level</InputLabel>
        <Select
          native
          value={state.age}
          onChange={handleChange}
          inputProps={{
            name: 'age',
            id: 'age-native-simple',
		
          }}
        >
          <option aria-label="None" value="" />
          <option value={10}>High School</option>
          <option value={20}>University</option>
          <option value={30}>professional formation</option>
        </Select>
      </FormControl>
        <TextField required id="standard-required" label="Required" defaultValue="Speciality"  variant="outlined" />
        
        
       
       
        <TextField required id="standard-required" label="Required" defaultValue="Title of the stage" variant="outlined" />
        
      </div>
      <div>
	  <Radio
        checked={selectedValue === 'a'}
        onChange={handleChange}
        value="a"
        name="radio-button-demo"
        inputProps={{ 'aria-label': 'A' }}
      />
      <Radio
        checked={selectedValue === 'b'}
        onChange={handleChange}
        value="b"
        name="radio-button-demo"
        inputProps={{ 'aria-label': 'B' }}
      />
       
        
         <TextField
          id="filled-helperText"
          label="Required*"
          defaultValue="what is you're job"
          helperText="Some important text"
          variant="outlined"
        />
       
		<TextField
          id="filled-number"
          label="Number expresion"
          type="number"
          InputLabelProps={{
            shrink: true,
          }}
        variant="outlined"
        />
      </div>
     
    </form>
  );
}
